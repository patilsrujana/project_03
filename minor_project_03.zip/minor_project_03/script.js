
const weatherKey = "YOUR_WEATHER_API_KEY";
const movieKey = "YOUR_OMDB_API_KEY";

// WEATHER APP
const weatherForm = document.getElementById("weatherForm");
const weatherResult = document.getElementById("weatherResult");

weatherForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const city = document.getElementById("city").value.trim();

    weatherResult.textContent = "Loading weather...";

    try {
        const url =
            `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${weatherKey}&units=metric`;

        const response = await fetch(url);
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || "City not found");
        }

        const { temp, humidity } = data.main;
        const { speed } = data.wind;
        const condition = data.weather[0].description;

        weatherResult.innerHTML = `
            <h3>${data.name}, ${data.sys.country}</h3>
            <p>🌡 Temperature: ${temp} °C</p>
            <p>☁ Condition: ${condition}</p>
            <p>💧 Humidity: ${humidity}%</p>
            <p>💨 Wind Speed: ${speed} m/s</p>
        `;
    } catch (error) {
        weatherResult.textContent =
            "Error: " + error.message +
            ". Check the city name and API key.";
    }
});


// MOVIE SEARCH APP
const movieForm = document.getElementById("movieForm");
const movieResult = document.getElementById("movieResult");

movieForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const movie = document.getElementById("movie").value.trim();

    movieResult.textContent = "Searching for movies...";

    try {
        const url =
            `https://www.omdbapi.com/?s=${encodeURIComponent(movie)}&apikey=${movieKey}`;

        const response = await fetch(url);
        const data = await response.json();

        if (data.Response === "False") {
            throw new Error(data.Error || "No movies found");
        }

        movieResult.innerHTML = "";

        data.Search.forEach((item) => {
            const card = document.createElement("div");
            card.className = "movie-card";

            const poster = document.createElement("img");
            poster.alt = `${item.Title} poster`;

            if (item.Poster !== "N/A") {
                poster.src = item.Poster;
            } else {
                poster.alt = "Poster not available";
            }

            const title = document.createElement("h3");
            title.textContent = item.Title;

            const year = document.createElement("p");
            year.textContent = `Release year: ${item.Year}`;

            const type = document.createElement("p");
            type.textContent = `Type: ${item.Type}`;

            card.append(poster, title, year, type);
            movieResult.appendChild(card);
        });

    } catch (error) {
        movieResult.textContent =
            "Error: " + error.message +
            ". Try another movie or check your API key.";
    }
});
